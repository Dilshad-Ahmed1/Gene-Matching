import React, { useState } from 'react';
import DNASequenceInput from '../components/DNASequenceInput';
import PatternInput from '../components/PatternInput';
import AlgorithmSelection from '../components/AlgorithmSelection';
import ResultsTable, { AlgorithmResult } from '../components/ResultsTable';
import ResultsChart from '../components/ResultsChart';
import DNASequenceViewer from '../components/DNASequenceViewer';
import StepModeModal from '../components/StepModeModal';
import { Play, X, StepForward } from 'lucide-react';
import { bruteForce } from '../algorithms/bruteForce';
import { horspool } from '../algorithms/horspool';
import { boyerMoore } from '../algorithms/boyerMoore';

const AnalysisToolPage: React.FC = () => {
  const [dnaSequence, setDnaSequence] = useState<string>('');
  const [pattern, setPattern] = useState<string>('');
  const [results, setResults] = useState<AlgorithmResult[]>([]);
  const [selectedAlgorithm, setSelectedAlgorithm] = useState<string | null>(null);
  const [isStepMode, setIsStepMode] = useState(false);
  const [stepModeAlgorithm, setStepModeAlgorithm] = useState<string>('');
  const [highlightPosition, setHighlightPosition] = useState<number | undefined>();
  const [highlightLength, setHighlightLength] = useState<number>(0);
  
  const [algorithms, setAlgorithms] = useState([
    {
      id: 'bruteForce',
      name: 'Brute-Force',
      description: 'Checks every possible alignment of the pattern with the sequence.',
      selected: true
    },
    {
      id: 'horspool',
      name: 'Horspool',
      description: 'Uses bad character rule to skip portions of the text.',
      selected: true
    },
    {
      id: 'boyerMoore',
      name: 'Boyer-Moore',
      description: 'Uses both bad character and good suffix rules for maximum efficiency.',
      selected: true
    }
  ]);

  const handleAlgorithmChange = (id: string, selected: boolean) => {
    setAlgorithms(algorithms.map(algo => 
      algo.id === id ? { ...algo, selected } : algo
    ));
  };

  const handleRunAnalysis = () => {
    const newResults: AlgorithmResult[] = [];
    
    algorithms.forEach(algo => {
      if (!algo.selected) return;
      
      let result;
      switch (algo.id) {
        case 'bruteForce':
          result = bruteForce(dnaSequence, pattern);
          break;
        case 'horspool':
          result = horspool(dnaSequence, pattern);
          break;
        case 'boyerMoore':
          result = boyerMoore(dnaSequence, pattern);
          break;
        default:
          return;
      }
      
      newResults.push({
        name: algo.name,
        ...result
      });
    });
    
    setResults(newResults);
  };

  const handleClear = () => {
    setDnaSequence('');
    setPattern('');
    setResults([]);
    setSelectedAlgorithm(null);
    setHighlightPosition(undefined);
    setHighlightLength(0);
  };

  const handleStepMode = (algorithmName: string) => {
    setStepModeAlgorithm(algorithmName);
    setIsStepMode(true);
  };

  const handleStepModeClose = () => {
    setIsStepMode(false);
    setHighlightPosition(undefined);
    setHighlightLength(0);
  };

  const handleHighlight = (position: number, length: number) => {
    setHighlightPosition(position);
    setHighlightLength(length);
  };

  const isValidInput = () => {
    return dnaSequence.length > 0 && 
           pattern.length > 0 && 
           algorithms.some(algo => algo.selected);
  };

  const getMatchesForVisualization = () => {
    return results.map(result => ({
      algorithm: result.name,
      positions: result.positions,
      color: result.name === 'Brute-Force' ? 'red' :
             result.name === 'Horspool' ? 'green' : 'blue'
    }));
  };
  
  return (
    <div className="max-w-7xl mx-auto">
      <h1 className="text-3xl font-bold text-gray-800 mb-6">DNA Pattern Matching Analysis</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left Panel: Inputs */}
        <div className="lg:col-span-1">
          <div className="bg-white p-6 rounded-lg shadow-md space-y-6">
            <DNASequenceInput 
              value={dnaSequence} 
              onChange={setDnaSequence} 
            />
            
            <PatternInput 
              value={pattern} 
              onChange={setPattern} 
            />
            
            <AlgorithmSelection 
              algorithms={algorithms} 
              onChange={handleAlgorithmChange} 
            />
            
            <div className="flex flex-wrap gap-3 pt-4">
              <button
                className={`inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 ${
                  !isValidInput() ? 'opacity-50 cursor-not-allowed' : ''
                }`}
                onClick={handleRunAnalysis}
                disabled={!isValidInput()}
              >
                <Play className="h-4 w-4 mr-1" />
                Run Analysis
              </button>
              
              <button
                className={`inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 ${
                  !isValidInput() ? 'opacity-50 cursor-not-allowed' : ''
                }`}
                onClick={() => handleStepMode(algorithms.find(a => a.selected)?.name || '')}
                disabled={!isValidInput()}
              >
                <StepForward className="h-4 w-4 mr-1" />
                Step Mode
              </button>
              
              <button
                className={`inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 ${
                  !dnaSequence && !pattern ? 'opacity-50 cursor-not-allowed' : ''
                }`}
                onClick={handleClear}
                disabled={!dnaSequence && !pattern}
              >
                <X className="h-4 w-4 mr-1" />
                Clear All
              </button>
            </div>
          </div>
        </div>
        
        {/* Right Panel: Results */}
        <div className="lg:col-span-1 space-y-6">
          <DNASequenceViewer
            sequence={dnaSequence}
            pattern={pattern}
            matches={getMatchesForVisualization()}
            showAlgorithm={selectedAlgorithm}
            highlightPosition={highlightPosition}
            highlightLength={highlightLength}
          />
          
          <ResultsTable 
            results={results}
            onAlgorithmClick={setSelectedAlgorithm}
            selectedAlgorithm={selectedAlgorithm}
          />
          
          {results.length > 0 && <ResultsChart results={results} />}
        </div>
      </div>

      {isStepMode && (
        <StepModeModal
          isOpen={isStepMode}
          onClose={handleStepModeClose}
          sequence={dnaSequence}
          pattern={pattern}
          algorithm={stepModeAlgorithm}
          onHighlight={handleHighlight}
        />
      )}
    </div>
  );
};

export default AnalysisToolPage;