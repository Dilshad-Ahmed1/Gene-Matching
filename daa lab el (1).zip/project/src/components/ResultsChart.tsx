import React from 'react';
import { Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { AlgorithmResult } from './ResultsTable';

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

interface ResultsChartProps {
  results: AlgorithmResult[];
}

const ResultsChart: React.FC<ResultsChartProps> = ({ results }) => {
  if (results.length === 0) {
    return null;
  }
  
  const algorithmNames = results.map(result => result.name);
  const executionTimes = results.map(result => result.executionTime);
  const comparisons = results.map(result => result.comparisons);
  
  // Normalize the data for better visualization
  const maxComparisons = Math.max(...comparisons);
  const normalizedComparisons = comparisons.map(value => 
    (value / maxComparisons) * Math.max(...executionTimes)
  );
  
  const data = {
    labels: algorithmNames,
    datasets: [
      {
        label: 'Execution Time (ms)',
        data: executionTimes,
        backgroundColor: 'rgba(54, 162, 235, 0.5)',
        borderColor: 'rgba(54, 162, 235, 1)',
        borderWidth: 1,
      },
      {
        label: 'Comparisons (normalized)',
        data: normalizedComparisons,
        backgroundColor: 'rgba(255, 99, 132, 0.5)',
        borderColor: 'rgba(255, 99, 132, 1)',
        borderWidth: 1,
      }
    ]
  };
  
  const options = {
    responsive: true,
    scales: {
      y: {
        beginAtZero: true,
        title: {
          display: true,
          text: 'Execution Time (ms)'
        }
      },
      x: {
        title: {
          display: true,
          text: 'Algorithm'
        }
      }
    },
    plugins: {
      tooltip: {
        callbacks: {
          label: function(context: any) {
            const datasetLabel = context.dataset.label || '';
            const value = context.parsed.y;
            const datasetIndex = context.datasetIndex;
            
            if (datasetIndex === 0) {
              return datasetLabel + ': ' + value.toFixed(3) + ' ms';
            } else if (datasetIndex === 1) {
              // For the comparisons dataset, show the actual comparisons
              return 'Comparisons: ' + comparisons[context.dataIndex].toLocaleString();
            }
            return datasetLabel + ': ' + value;
          }
        }
      },
      legend: {
        position: 'top' as const,
      },
      title: {
        display: true,
        text: 'Algorithm Performance Comparison',
      },
    },
  };
  
  return (
    <div className="bg-white p-6 rounded-lg shadow-md mt-6">
      <h3 className="text-lg font-medium text-gray-900 mb-4">Performance Comparison</h3>
      <Bar data={data} options={options} />
      <div className="mt-3 text-xs text-gray-500 text-center">
        Note: Comparisons are normalized to fit the same scale as execution time
      </div>
    </div>
  );
};

export default ResultsChart;