import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Search, Clock, LineChart } from 'lucide-react';

const HomePage: React.FC = () => {
  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex flex-col items-center text-center py-12 px-4">
        <h1 className="text-4xl md:text-5xl font-bold text-gray-800 mb-6">
          DNA Pattern Matching Laboratory
        </h1>
        
        <p className="text-xl text-gray-600 max-w-3xl mb-10">
          Compare Brute-Force, Horspool, and Boyer-Moore algorithms for DNA sequence search and analysis.
          Visualize the process, measure performance, and understand the science behind pattern matching.
        </p>
        
        <Link 
          to="/analysis" 
          className="inline-flex items-center bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 px-8 rounded-lg transition-colors duration-200"
        >
          Start Analysis
          <ArrowRight className="ml-2 h-5 w-5" />
        </Link>

        <div className="grid md:grid-cols-3 gap-8 mt-16 w-full max-w-4xl">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="bg-blue-100 rounded-full w-12 h-12 flex items-center justify-center mb-4 mx-auto">
              <Search className="h-6 w-6 text-blue-600" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Pattern Matching</h3>
            <p className="text-gray-600">
              Efficiently search for DNA patterns using multiple algorithms optimized for biological sequences.
            </p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="bg-green-100 rounded-full w-12 h-12 flex items-center justify-center mb-4 mx-auto">
              <Clock className="h-6 w-6 text-green-600" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Real-time Analysis</h3>
            <p className="text-gray-600">
              Watch algorithms in action with step-by-step visualization and detailed performance metrics.
            </p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="bg-purple-100 rounded-full w-12 h-12 flex items-center justify-center mb-4 mx-auto">
              <LineChart className="h-6 w-6 text-purple-600" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Performance Comparison</h3>
            <p className="text-gray-600">
              Compare algorithm efficiency with detailed metrics and interactive visualizations.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;